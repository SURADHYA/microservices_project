package com.amigoscode.clients.fraud;

public record FraudCheckResponse(Boolean isFraudster) {
}
